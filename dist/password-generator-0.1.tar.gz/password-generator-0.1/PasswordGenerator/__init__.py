from PasswordGenerator.provider import generate_password

__all__ = ['generate_password']