from setuptools import setup

setup(
    name='password-generator',
    version='0.1',
    description='Password Generator',
    url='https://github.com/abbaskhanezad/password-generator',
    author='abbas khanezad',
    author_email='abbas.khanezad@gmail.com',
    license='MIT',
    packages=['PasswordGenerator'],
    zip_safe=False

)